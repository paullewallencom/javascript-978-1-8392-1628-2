//Declar Variable
var name = "Steven";

test();
console.log(greeting + name + punctuation);

var greeting = "Hello there ";

var punctuation = "!";

function test() {
    console.log(greeting + name + punctuation);
}
