//Find where the third B is in the sentence.
var sentence = "The brown bear jumped over the Big fence!";