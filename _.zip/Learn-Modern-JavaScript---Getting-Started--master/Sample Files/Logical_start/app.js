var userName;

if (userName !== undefined) {
    console.log("User is: " + userName);
} else {
    console.log("User is not defined.");
}