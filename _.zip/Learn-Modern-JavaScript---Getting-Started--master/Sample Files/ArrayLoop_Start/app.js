//Determine an average of all the grades
var grades = [97, 32, 65, 88,, 45, 78, 76, 83, 67, 97];

