//Create a function that will sum two numbers
var sum = function (num1 = 0, num2 = 0) {
    var total = 0;
    total = num1 + num2;
    console.log(total);
};

sum(5, 6);
sum(100, -4);

sum(7);