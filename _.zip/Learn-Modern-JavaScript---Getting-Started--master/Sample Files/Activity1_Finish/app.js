//Declare variable
var name = "Steven";
//Print the variable to the console.
console.log("Welcome " + name + "!");
/* This is comment
more comment
*/
