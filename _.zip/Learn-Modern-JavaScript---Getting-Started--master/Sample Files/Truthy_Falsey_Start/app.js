var userName;

if (userName !== undefined && userName !== null) {
    console.log("User is: " + userName);
} else {
    console.log("User is not defined.");
}