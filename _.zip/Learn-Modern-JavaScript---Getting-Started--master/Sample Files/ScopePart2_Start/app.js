
function test1() {
    var num1 = 10;
    //console.log("1: " + num1);
    //console.log("2: " + num2);
    for (var i = 1; i < 5; i++) {
        console.log(i);
    }
    console.log(i);
}

test1();
var num1 = 25,
    num2 = 75;
    