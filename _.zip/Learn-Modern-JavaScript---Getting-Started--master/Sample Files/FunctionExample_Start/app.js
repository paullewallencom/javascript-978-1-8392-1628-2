//Create a function that will generate a random number between the numbers provided.
