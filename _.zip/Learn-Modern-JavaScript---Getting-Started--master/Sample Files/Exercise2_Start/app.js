//Print a random number from 1 - 10 to the console.
