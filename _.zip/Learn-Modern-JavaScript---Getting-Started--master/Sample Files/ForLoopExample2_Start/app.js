//Find the multiples of 6 between 1 and 100
