//Print a random number from 0 - 10 to the console.
var num = Math.random(),
    finalNum = num * 10;

console.log(Math.round(finalNum));