
var greeting = function() {
    console.log("Hello There!");
};
