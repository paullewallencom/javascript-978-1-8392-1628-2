//Write conditionals to sort three numbers 6, -5, 2. Output the results to the console.
