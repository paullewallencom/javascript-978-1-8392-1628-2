//Find out how many hours have passed since 1/1/2000.

//Print it to the console.