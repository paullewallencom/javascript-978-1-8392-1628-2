

function init() {
    "use strict";
    x = 5 + 6;
}

init();