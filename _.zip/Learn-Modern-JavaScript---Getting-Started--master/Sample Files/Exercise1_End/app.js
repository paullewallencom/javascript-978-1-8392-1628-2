var firstName = "Steven";
var lastName = "Hancock";

console.log(firstName + " " + lastName);