//create date object

//print date in formation day/month/year
